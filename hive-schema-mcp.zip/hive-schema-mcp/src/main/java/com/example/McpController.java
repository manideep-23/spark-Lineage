package com.example;

import org.springframework.web.bind.annotation.*;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

@RestController
@RequestMapping("/mcp")
public class McpController {

    @PostMapping("/describe")
    public Object describe(@RequestBody Map<String, String> body) throws Exception {

        String table = body.get("table");

        if (!table.matches("^[a-zA-Z0-9_]+$")) {
            throw new RuntimeException("Invalid table name");
        }

        String sql = "DESCRIBE " + table;

        try (Statement stmt = HiveConfig.connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            List<Map<String, String>> result = new ArrayList<>();

            while (rs.next()) {
                Map<String, String> row = new HashMap<>();
                row.put("column", rs.getString(1));
                row.put("type", rs.getString(2));
                result.add(row);
            }

            return result;
        }
    }
}
