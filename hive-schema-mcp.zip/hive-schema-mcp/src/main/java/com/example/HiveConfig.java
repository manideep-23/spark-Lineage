package com.example;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Base64;

@Configuration
public class HiveConfig {

    @Value("${hive.url}")
    private String hiveUrl;

    @Value("${hive.principal}")
    private String principal;

    @Value("${hive.keytabBase64}")
    private String keytabBase64;

    public static Connection connection;

    @PostConstruct
    public void init() throws Exception {

        System.setProperty("javax.security.auth.useSubjectCredsOnly", "false");

        byte[] decoded = Base64.getDecoder().decode(keytabBase64);
        Path tempKeytab = Files.createTempFile("hive-", ".keytab");
        Files.write(tempKeytab, decoded);

        org.apache.hadoop.conf.Configuration conf =
                new org.apache.hadoop.conf.Configuration();

        org.apache.hadoop.security.UserGroupInformation.setConfiguration(conf);
        org.apache.hadoop.security.UserGroupInformation
                .loginUserFromKeytab(principal, tempKeytab.toString());

        Class.forName("org.apache.hive.jdbc.HiveDriver");
        connection = DriverManager.getConnection(hiveUrl);

        tempKeytab.toFile().deleteOnExit();
    }
}
